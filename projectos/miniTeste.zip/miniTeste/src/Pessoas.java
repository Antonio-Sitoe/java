import javax.swing.*;

public class Pessoas {
    private JTextField textField1;
}
